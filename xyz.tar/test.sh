
Conversation opened. 1 read message.

Skip to content
Using Gmail with screen readers
Enable desktop notifications for Gmail.   OK  No thanks
SD LAB - Exercise - 1
John Prakash <johnprakash@gmail.com>
	
AttachmentsJan 29, 2019, 9:14 AM (2 days ago)
	
to mca_cet_2017_2020 Unsubscribe
Students,

Todays exercise is to get familiarized with shell comands.
Shell is the command interpreter for Linux.
use these commands along with its various options.

1. echo, read
2. more, less
3. man
4. chmod, chown
5. cd, mkdir, pwd, ls, find
6. cat, mv, cp, rm
7. wc, cut, paste
8. head, tail, grep, expr
9. Redirections & Piping
10. useradd, usermod, userdel, passwd
11. tar

Go through the resource material attached.
Prepare a documentation for the above commands not exceeding 11 pages and submit in A4 double side - hand written in plastic slide folder unclipped on  or before 04-02-2019 - 9AM.

Regards 
John Prakash Joseph,
Associate Professor 
Room No CA202
Department of Computer Applications
College of Engineering Trivandrum
Thiruvananthapuram - 695 016
ph: 9495502400.


email : john@cet.ac.in
2 Attachments
	
	
	

